<?php 
	
	Route::resource('api/tipo', 'TipoController');