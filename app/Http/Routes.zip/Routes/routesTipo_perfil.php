<?php 

	Route::resource('api/tipoperfil', 'Tipo_perfilController');