<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tipo_permiso extends Model
{
    protected $table = "tipo_permiso";
    
    public $timestamps = false;
}
