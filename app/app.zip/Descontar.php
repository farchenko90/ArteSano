<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Descontar extends Model
{
    protected $table = "descontar";
    
    public $timestamps = false;
}
