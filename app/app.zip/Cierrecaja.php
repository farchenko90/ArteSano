<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cierrecaja extends Model
{
    protected $table = "cierrecaja";
    
    public $timestamps = false;
}
